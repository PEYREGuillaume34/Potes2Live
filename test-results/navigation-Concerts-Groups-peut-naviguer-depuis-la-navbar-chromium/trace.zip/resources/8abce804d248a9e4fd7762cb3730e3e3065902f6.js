(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/actions/data:d4df34 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"00760ef52b3f8463e4a7673cc87f584c58f55b8c09":"getMyGroups"},"app/actions/groups.actions.ts",""] */ __turbopack_context__.s([
    "getMyGroups",
    ()=>getMyGroups
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var getMyGroups = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("00760ef52b3f8463e4a7673cc87f584c58f55b8c09", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getMyGroups"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ3JvdXBzLmFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc2VydmVyXCI7XHJcblxyXG5pbXBvcnQgeyBkYiB9IGZyb20gXCIuLi9saWIvZGIvZHJpenpsZVwiO1xyXG5pbXBvcnQgeyBncm91cHMsIGdyb3VwTWVtYmVycywgdXNlciwgZXZlbnRzIH0gZnJvbSBcIkAvYXBwL2xpYi9kYi9zY2hlbWFcIjtcclxuaW1wb3J0IHsgZXEsIGFuZCwgY291bnQsIHNxbCwgbHQsIGRlc2MsIGd0IH0gZnJvbSBcImRyaXp6bGUtb3JtXCI7XHJcbmltcG9ydCB7IGF1dGggfSBmcm9tIFwiQC9hcHAvbGliL2F1dGhcIjtcclxuaW1wb3J0IHsgaGVhZGVycyB9IGZyb20gXCJuZXh0L2hlYWRlcnNcIjtcclxuXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gUsOJQ1VQw4lSRVIgTEVTIEdST1VQRVMgRCdVTiDDiVbDiU5FTUVOVFxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRHcm91cHNCeUV2ZW50KGV2ZW50SWQ6IG51bWJlcikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBncm91cHN3aXRoTWVtYmVycyA9IGF3YWl0IGRiXHJcbiAgICAgIC5zZWxlY3Qoe1xyXG4gICAgICAgIGlkOiBncm91cHMuaWQsXHJcbiAgICAgICAgbmFtZTogZ3JvdXBzLm5hbWUsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGdyb3Vwcy5kZXNjcmlwdGlvbixcclxuICAgICAgICBtYXhNZW1iZXJzOiBncm91cHMubWF4TWVtYmVycyxcclxuICAgICAgICBjcmVhdGVkQXQ6IGdyb3Vwcy5jcmVhdGVkQXQsXHJcbiAgICAgICAgb3duZXJJZDogZ3JvdXBzLm93bmVySWQsXHJcbiAgICAgICAgb3duZXI6IHtcclxuICAgICAgICAgIGlkOiB1c2VyLmlkLFxyXG4gICAgICAgICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgICAgICAgYXZhdGFyX3VybDogdXNlci5hdmF0YXJfdXJsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbWVtYmVyQ291bnQ6IGNvdW50KGdyb3VwTWVtYmVycy5pZCksXHJcbiAgICAgIH0pXHJcbiAgICAgIC5mcm9tKGdyb3VwcylcclxuICAgICAgLmlubmVySm9pbih1c2VyLCBlcShncm91cHMub3duZXJJZCwgdXNlci5pZCkpXHJcbiAgICAgIC5sZWZ0Sm9pbihcclxuICAgICAgICBncm91cE1lbWJlcnMsXHJcbiAgICAgICAgYW5kKFxyXG4gICAgICAgICAgZXEoZ3JvdXBzLmlkLCBncm91cE1lbWJlcnMuZ3JvdXBJZCksXHJcbiAgICAgICAgICBlcShncm91cE1lbWJlcnMuc3RhdHVzLCBcImFjdGl2ZVwiKVxyXG4gICAgICAgIClcclxuICAgICAgKVxyXG4gICAgICAud2hlcmUoYW5kKGVxKGdyb3Vwcy5ldmVudElkLCBldmVudElkKSwgZXEoZ3JvdXBzLmlzQWN0aXZlLCB0cnVlKSkpXHJcbiAgICAgIC5ncm91cEJ5KGdyb3Vwcy5pZCwgdXNlci5pZCk7XHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogZ3JvdXBzd2l0aE1lbWJlcnMgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycmV1ciByw6ljdXDDqXJhdGlvbiBncm91cGVzOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgZXJyb3I6IFwiRXJyZXVyIGxvcnMgZGUgbGEgcsOpY3Vww6lyYXRpb24gZGVzIGdyb3VwZXNcIixcclxuICAgIH07XHJcbiAgfVxyXG59XHJcblxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vIFbDiVJJRklFUiBTSSBMJ1VTRVIgQSBEw4lKw4AgVU4gR1JPVVBFIFBPVVIgQ0VUIEVWRU5UXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNoZWNrVXNlckdyb3VwRm9yRXZlbnQoZXZlbnRJZDogbnVtYmVyKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBhdXRoLmFwaS5nZXRTZXNzaW9uKHtcclxuICAgICAgaGVhZGVyczogYXdhaXQgaGVhZGVycygpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKCFzZXNzaW9uKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJOb24gYXV0aGVudGlmacOpXCIgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBbbWVtYmVyc2hpcF0gPSBhd2FpdCBkYlxyXG4gICAgICAuc2VsZWN0KHtcclxuICAgICAgICBncm91cElkOiBncm91cE1lbWJlcnMuZ3JvdXBJZCxcclxuICAgICAgICByb2xlOiBncm91cE1lbWJlcnMucm9sZSxcclxuICAgICAgfSlcclxuICAgICAgLmZyb20oZ3JvdXBNZW1iZXJzKVxyXG4gICAgICAuaW5uZXJKb2luKGdyb3VwcywgZXEoZ3JvdXBNZW1iZXJzLmdyb3VwSWQsIGdyb3Vwcy5pZCkpXHJcbiAgICAgIC53aGVyZShcclxuICAgICAgICBhbmQoXHJcbiAgICAgICAgICBlcShncm91cE1lbWJlcnMudXNlcklkLCBzZXNzaW9uLnVzZXIuaWQpLFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLnN0YXR1cywgXCJhY3RpdmVcIiksXHJcbiAgICAgICAgICBlcShncm91cHMuZXZlbnRJZCwgZXZlbnRJZCksXHJcbiAgICAgICAgICBlcShncm91cHMuaXNBY3RpdmUsIHRydWUpXHJcbiAgICAgICAgKVxyXG4gICAgICApXHJcbiAgICAgIC5saW1pdCgxKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdWNjZXNzOiB0cnVlLFxyXG4gICAgICBoYXNHcm91cDogISFtZW1iZXJzaGlwLFxyXG4gICAgICBncm91cElkOiBtZW1iZXJzaGlwPy5ncm91cElkID8/IG51bGwsXHJcbiAgICAgIHJvbGU6IG1lbWJlcnNoaXA/LnJvbGUgPz8gbnVsbCxcclxuICAgIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJldXIgdsOpcmlmaWNhdGlvbiBncm91cGUgZXhpc3RhbnQ6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjogXCJFcnJldXIgbG9ycyBkZSBsYSB2w6lyaWZpY2F0aW9uIGR1IGdyb3VwZVwiLFxyXG4gICAgfTtcclxuICB9XHJcbn1cclxuXHJcblxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vIENSw4lFUiBVTiBHUk9VUEVcclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlR3JvdXAoXHJcbiAgZXZlbnRJZDogbnVtYmVyLFxyXG4gIG5hbWU6IHN0cmluZyxcclxuICBkZXNjcmlwdGlvbjogc3RyaW5nLFxyXG4gIG1heE1lbWJlcnM6IG51bWJlciA9IDEwXHJcbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aC5hcGkuZ2V0U2Vzc2lvbih7XHJcbiAgICAgIGhlYWRlcnM6IGF3YWl0IGhlYWRlcnMoKSxcclxuICAgIH0pO1xyXG5cclxuICAgIGlmICghc2Vzc2lvbikge1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm9uIGF1dGhlbnRpZmnDqVwiIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gVsOpcmlmaWVyIHF1ZSBsJ3V0aWxpc2F0ZXVyIG4nYSBwYXMgZMOpasOgIGNyw6nDqSB1biBncm91cGUgcG91ciBjZXQgZXZlbnRcclxuICAgIGNvbnN0IGNoZWNrUmVzdWx0ID0gYXdhaXQgY2hlY2tVc2VyR3JvdXBGb3JFdmVudChldmVudElkKTtcclxuICAgIGlmIChjaGVja1Jlc3VsdC5oYXNHcm91cCkge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiBcIlZvdXMgYXZleiBkw6lqw6AgY3LDqcOpIHVuIGdyb3VwZSBwb3VyIGNldCDDqXbDqW5lbWVudFwiLFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFZhbGlkYXRpb24gZGVzIGRvbm7DqWVzXHJcbiAgICBpZiAoIW5hbWUgfHwgbmFtZS50cmltKCkubGVuZ3RoIDwgMykge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiBcIkxlIG5vbSBkdSBncm91cGUgZG9pdCBjb250ZW5pciBhdSBtb2lucyAzIGNhcmFjdMOocmVzXCIsXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKG1heE1lbWJlcnMgPCAyIHx8IG1heE1lbWJlcnMgPiA1MCkge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiBcIkxlIG5vbWJyZSBkZSBtZW1icmVzIGRvaXQgw6p0cmUgZW50cmUgMiBldCA1MFwiLFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENyw6llciBsZSBncm91cGVcclxuICAgIGNvbnN0IFtuZXdHcm91cF0gPSBhd2FpdCBkYlxyXG4gICAgICAuaW5zZXJ0KGdyb3VwcylcclxuICAgICAgLnZhbHVlcyh7XHJcbiAgICAgICAgZXZlbnRJZCxcclxuICAgICAgICBvd25lcklkOiBzZXNzaW9uLnVzZXIuaWQsXHJcbiAgICAgICAgbmFtZTogbmFtZS50cmltKCksXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uPy50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICBtYXhNZW1iZXJzLFxyXG4gICAgICAgIGlzQWN0aXZlOiB0cnVlLFxyXG4gICAgICB9KVxyXG4gICAgICAucmV0dXJuaW5nKCk7XHJcblxyXG4gICAgLy8gQWpvdXRlciBsZSBjcsOpYXRldXIgZW4gdGFudCBxdWUgbWVtYnJlIGFjdGlmIGR1IGdyb3VwZVxyXG4gICAgYXdhaXQgZGIuaW5zZXJ0KGdyb3VwTWVtYmVycykudmFsdWVzKHtcclxuICAgICAgZ3JvdXBJZDogbmV3R3JvdXAuaWQsXHJcbiAgICAgIHVzZXJJZDogc2Vzc2lvbi51c2VyLmlkLFxyXG4gICAgICByb2xlOiBcIm93bmVyXCIsXHJcbiAgICAgIHN0YXR1czogXCJhY3RpdmVcIixcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IG5ld0dyb3VwIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJldXIgY3LDqWF0aW9uIGdyb3VwZTpcIiwgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkVycmV1ciBsb3JzIGRlIGxhIGNyw6lhdGlvbiBkdSBncm91cGVcIiB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyBSRUpPSU5EUkUgVU4gR1JPVVBFXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGpvaW5Hcm91cChncm91cElkOiBudW1iZXIpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGF1dGguYXBpLmdldFNlc3Npb24oe1xyXG4gICAgICBoZWFkZXJzOiBhd2FpdCBoZWFkZXJzKCksXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoIXNlc3Npb24pIHtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vbiBhdXRoZW50aWZpw6lcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFbDqXJpZmllciBzaSBsZSBncm91cGUgZXhpc3RlIGV0IGVzdCBhY3RpZlxyXG4gICAgY29uc3QgW2dyb3VwXSA9IGF3YWl0IGRiXHJcbiAgICAgIC5zZWxlY3QoKVxyXG4gICAgICAuZnJvbShncm91cHMpXHJcbiAgICAgIC53aGVyZShhbmQoZXEoZ3JvdXBzLmlkLCBncm91cElkKSwgZXEoZ3JvdXBzLmlzQWN0aXZlLCB0cnVlKSkpXHJcbiAgICAgIC5saW1pdCgxKTtcclxuXHJcbiAgICBpZiAoIWdyb3VwKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJHcm91cGUgaW50cm91dmFibGUgb3UgaW5hY3RpZlwiIH07XHJcbiAgICB9XHJcblxyXG4gICAgICAgIC8vIFbDqXJpZmllciBzaSBsJ3V0aWxpc2F0ZXVyIGVzdCBkw6lqw6AgZGFucyB1biBhdXRyZSBncm91cGUgcG91ciBjZXQgw6l2w6luZW1lbnRcclxuICAgIGNvbnN0IFtleGlzdGluZ0dyb3VwRm9yRXZlbnRdID0gYXdhaXQgZGJcclxuICAgICAgLnNlbGVjdCh7XHJcbiAgICAgICAgZ3JvdXBJZDogZ3JvdXBNZW1iZXJzLmdyb3VwSWQsXHJcbiAgICAgICAgZ3JvdXBOYW1lOiBncm91cHMubmFtZSxcclxuICAgICAgfSlcclxuICAgICAgLmZyb20oZ3JvdXBNZW1iZXJzKVxyXG4gICAgICAuaW5uZXJKb2luKGdyb3VwcywgZXEoZ3JvdXBNZW1iZXJzLmdyb3VwSWQsIGdyb3Vwcy5pZCkpXHJcbiAgICAgIC53aGVyZShcclxuICAgICAgICBhbmQoXHJcbiAgICAgICAgICBlcShncm91cE1lbWJlcnMudXNlcklkLCBzZXNzaW9uLnVzZXIuaWQpLFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLnN0YXR1cywgXCJhY3RpdmVcIiksXHJcbiAgICAgICAgICBlcShncm91cHMuZXZlbnRJZCwgZ3JvdXAuZXZlbnRJZCksXHJcbiAgICAgICAgICBlcShncm91cHMuaXNBY3RpdmUsIHRydWUpXHJcbiAgICAgICAgKVxyXG4gICAgICApXHJcbiAgICAgIC5saW1pdCgxKTtcclxuXHJcbiAgICBpZiAoZXhpc3RpbmdHcm91cEZvckV2ZW50KSB7XHJcbiAgICAgIHJldHVybiB7IFxyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLCBcclxuICAgICAgICBlcnJvcjogYFZvdXMgw6p0ZXMgZMOpasOgIG1lbWJyZSBkdSBncm91cGUgXCIke2V4aXN0aW5nR3JvdXBGb3JFdmVudC5ncm91cE5hbWV9XCIgcG91ciBjZXQgw6l2w6luZW1lbnRgIFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFbDqXJpZmllciBzaSBsJ3V0aWxpc2F0ZXVyIGVzdCBkw6lqw6AgbWVtYnJlIGR1IGdyb3VwZVxyXG4gICAgY29uc3QgW2V4aXN0aW5nTWVtYmVyXSA9IGF3YWl0IGRiXHJcbiAgICAgIC5zZWxlY3QoKVxyXG4gICAgICAuZnJvbShncm91cE1lbWJlcnMpXHJcbiAgICAgIC53aGVyZShcclxuICAgICAgICBhbmQoXHJcbiAgICAgICAgICBlcShncm91cE1lbWJlcnMuZ3JvdXBJZCwgZ3JvdXBJZCksXHJcbiAgICAgICAgICBlcShncm91cE1lbWJlcnMudXNlcklkLCBzZXNzaW9uLnVzZXIuaWQpXHJcbiAgICAgICAgKVxyXG4gICAgICApXHJcbiAgICAgIC5saW1pdCgxKTtcclxuXHJcbiAgICAvLyBTaSBkw6lqw6AgbWVtYnJlIGV0IGFjdGlmXHJcbiAgICBpZiAoZXhpc3RpbmdNZW1iZXIgJiYgZXhpc3RpbmdNZW1iZXIuc3RhdHVzID09PSBcImFjdGl2ZVwiKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJWb3VzIMOqdGVzIGTDqWrDoCBtZW1icmUgZGUgY2UgZ3JvdXBlXCIgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTaSBtZW1icmUgbWFpcyBhIHF1aXR0w6kgKGxlZnQpIC0+IHLDqWFjdGl2ZXJcclxuICAgIGlmIChleGlzdGluZ01lbWJlciAmJiBleGlzdGluZ01lbWJlci5zdGF0dXMgPT09IFwibGVmdFwiKSB7XHJcbiAgICAgIC8vIFbDqXJpZmllciBzaSBsZSBncm91cGUgbidlc3QgcGFzIHBsZWluXHJcbiAgICAgIGNvbnN0IG1lbWJlckNvdW50ID0gYXdhaXQgZGJcclxuICAgICAgICAuc2VsZWN0KHsgY291bnQ6IGNvdW50KCkgfSlcclxuICAgICAgICAuZnJvbShncm91cE1lbWJlcnMpXHJcbiAgICAgICAgLndoZXJlKFxyXG4gICAgICAgICAgYW5kKFxyXG4gICAgICAgICAgICBlcShncm91cE1lbWJlcnMuZ3JvdXBJZCwgZ3JvdXBJZCksXHJcbiAgICAgICAgICAgIGVxKGdyb3VwTWVtYmVycy5zdGF0dXMsIFwiYWN0aXZlXCIpXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChtZW1iZXJDb3VudFswXS5jb3VudCA+PSBncm91cC5tYXhNZW1iZXJzKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkxlIGdyb3VwZSBlc3QgY29tcGxldFwiIH07XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFLDqWFjdGl2ZXIgbGUgbWVtYnJlXHJcbiAgICAgIGF3YWl0IGRiXHJcbiAgICAgICAgLnVwZGF0ZShncm91cE1lbWJlcnMpXHJcbiAgICAgICAgLnNldCh7IHN0YXR1czogXCJhY3RpdmVcIiB9KVxyXG4gICAgICAgIC53aGVyZShcclxuICAgICAgICAgIGFuZChcclxuICAgICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLmdyb3VwSWQsIGdyb3VwSWQpLFxyXG4gICAgICAgICAgICBlcShncm91cE1lbWJlcnMudXNlcklkLCBzZXNzaW9uLnVzZXIuaWQpXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIG1lc3NhZ2U6IFwiVm91cyBhdmV6IHJlam9pbnQgw6Agbm91dmVhdSBsZSBncm91cGVcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFbDqXJpZmllciBzaSBsZSBncm91cGUgZXN0IGTDqWrDoCBwbGVpblxyXG4gICAgY29uc3QgbWVtYmVyQ291bnQgPSBhd2FpdCBkYlxyXG4gICAgICAuc2VsZWN0KHsgY291bnQ6IGNvdW50KCkgfSlcclxuICAgICAgLmZyb20oZ3JvdXBNZW1iZXJzKVxyXG4gICAgICAud2hlcmUoXHJcbiAgICAgICAgYW5kKFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLmdyb3VwSWQsIGdyb3VwSWQpLFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLnN0YXR1cywgXCJhY3RpdmVcIilcclxuICAgICAgICApXHJcbiAgICAgICk7XHJcblxyXG4gICAgaWYgKG1lbWJlckNvdW50WzBdLmNvdW50ID49IGdyb3VwLm1heE1lbWJlcnMpIHtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIkxlIGdyb3VwZSBlc3QgY29tcGxldFwiIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUmVqb2luZHJlIGxlIGdyb3VwZSAobm91dmVhdSBtZW1icmUpXHJcbiAgICBhd2FpdCBkYi5pbnNlcnQoZ3JvdXBNZW1iZXJzKS52YWx1ZXMoe1xyXG4gICAgICBncm91cElkOiBncm91cElkLFxyXG4gICAgICB1c2VySWQ6IHNlc3Npb24udXNlci5pZCxcclxuICAgICAgcm9sZTogXCJtZW1iZXJcIixcclxuICAgICAgc3RhdHVzOiBcImFjdGl2ZVwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgbWVzc2FnZTogXCJWb3VzIGF2ZXogcmVqb2ludCBsZSBncm91cGVcIiB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyZXVyIHJlam9pbmRyZSBncm91cGU6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjogXCJFcnJldXIgbG9ycyBkZSBsYSB0ZW50YXRpdmUgZGUgcmVqb2luZHJlIGxlIGdyb3VwZVwiLFxyXG4gICAgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gUVVJVFRFUiBVTiBHUk9VUEVcclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbGVhdmVHcm91cChncm91cElkOiBudW1iZXIpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGF1dGguYXBpLmdldFNlc3Npb24oe1xyXG4gICAgICBoZWFkZXJzOiBhd2FpdCBoZWFkZXJzKCksXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoIXNlc3Npb24pIHtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vbiBhdXRoZW50aWZpw6lcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFbDqXJpZmllciBxdWUgbCd1dGlsaXNhdGV1ciBlc3QgbWVtYnJlIGR1IGdyb3VwZVxyXG4gICAgY29uc3QgW21lbWJlcl0gPSBhd2FpdCBkYlxyXG4gICAgICAuc2VsZWN0KClcclxuICAgICAgLmZyb20oZ3JvdXBNZW1iZXJzKVxyXG4gICAgICAud2hlcmUoXHJcbiAgICAgICAgYW5kKFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLmdyb3VwSWQsIGdyb3VwSWQpLFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLnVzZXJJZCwgc2Vzc2lvbi51c2VyLmlkKSxcclxuICAgICAgICAgIGVxKGdyb3VwTWVtYmVycy5zdGF0dXMsIFwiYWN0aXZlXCIpXHJcbiAgICAgICAgKVxyXG4gICAgICApXHJcbiAgICAgIC5saW1pdCgxKTtcclxuXHJcbiAgICBpZiAoIW1lbWJlcikge1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiVm91cyBuJ8OqdGVzIHBhcyBtZW1icmUgZGUgY2UgZ3JvdXBlXCIgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBNZXR0cmUgw6Agam91ciBsZSBzdGF0dXQgZHUgbWVtYnJlIMOgIFwibGVmdFwiXHJcbiAgICBhd2FpdCBkYlxyXG4gICAgICAudXBkYXRlKGdyb3VwTWVtYmVycylcclxuICAgICAgLnNldCh7IHN0YXR1czogXCJsZWZ0XCIgfSlcclxuICAgICAgLndoZXJlKFxyXG4gICAgICAgIGFuZChcclxuICAgICAgICAgIGVxKGdyb3VwTWVtYmVycy5ncm91cElkLCBncm91cElkKSxcclxuICAgICAgICAgIGVxKGdyb3VwTWVtYmVycy51c2VySWQsIHNlc3Npb24udXNlci5pZClcclxuICAgICAgICApXHJcbiAgICAgICk7XHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgbWVzc2FnZTogXCJWb3VzIGF2ZXogcXVpdHTDqSBsZSBncm91cGVcIiB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyZXVyIHF1aXR0ZXIgZ3JvdXBlOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgZXJyb3I6IFwiRXJyZXVyIGxvcnMgZGUgbGEgdGVudGF0aXZlIGRlIHF1aXR0ZXIgbGUgZ3JvdXBlXCIsXHJcbiAgICB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyBTVVBQUklNRVIgVU4gR1JPVVBFIChPd25lciB1bmlxdWVtZW50KVxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVHcm91cChncm91cElkOiBudW1iZXIpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGF1dGguYXBpLmdldFNlc3Npb24oe1xyXG4gICAgICBoZWFkZXJzOiBhd2FpdCBoZWFkZXJzKCksXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoIXNlc3Npb24pIHtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vbiBhdXRoZW50aWZpw6lcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFbDqXJpZmllciBzaSBsJ3V0aWxpc2F0ZXVyIGVzdCBsZSBwcm9wcmnDqXRhaXJlIGR1IGdyb3VwZVxyXG4gICAgY29uc3QgW2dyb3VwXSA9IGF3YWl0IGRiXHJcbiAgICAgIC5zZWxlY3QoKVxyXG4gICAgICAuZnJvbShncm91cHMpXHJcbiAgICAgIC53aGVyZShlcShncm91cHMuaWQsIGdyb3VwSWQpKVxyXG4gICAgICAubGltaXQoMSk7XHJcblxyXG4gICAgaWYgKCFncm91cCkge1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiR3JvdXBlIGludHJvdXZhYmxlXCIgfTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZ3JvdXAub3duZXJJZCAhPT0gc2Vzc2lvbi51c2VyLmlkKSB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgZXJyb3I6IFwiU2V1bCBsZSBjcsOpYXRldXIgcGV1dCBzdXBwcmltZXIgbGUgZ3JvdXBlXCIsXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRMOpc2FjdGl2ZXIgbGUgZ3JvdXBlIChzb2Z0IGRlbGV0ZSlcclxuICAgIGF3YWl0IGRiXHJcbiAgICAgIC51cGRhdGUoZ3JvdXBzKVxyXG4gICAgICAuc2V0KHsgaXNBY3RpdmU6IGZhbHNlIH0pXHJcbiAgICAgIC53aGVyZShlcShncm91cHMuaWQsIGdyb3VwSWQpKTtcclxuXHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBtZXNzYWdlOiBcIkxlIGdyb3VwZSBhIMOpdMOpIHN1cHByaW3DqVwiIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJldXIgc3VwcHJlc3Npb24gZ3JvdXBlOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRXJyZXVyIGxvcnMgZGUgbGEgc3VwcHJlc3Npb24gZHUgZ3JvdXBlXCIgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gUsOJQ1VQw4lSRVIgVE9VUyBMRVMgR1JPVVBFUyBERSBMJ1VUSUxJU0FURVVSIENPTk5FQ1TDiVxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNeUdyb3VwcygpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGF1dGguYXBpLmdldFNlc3Npb24oe1xyXG4gICAgICBoZWFkZXJzOiBhd2FpdCBoZWFkZXJzKCksXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoIXNlc3Npb24pIHtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBcIk5vbiBhdXRoZW50aWZpw6lcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG15R3JvdXBzID0gYXdhaXQgZGJcclxuICAgICAgLnNlbGVjdCh7XHJcbiAgICAgICAgaWQ6IGdyb3Vwcy5pZCxcclxuICAgICAgICBuYW1lOiBncm91cHMubmFtZSxcclxuICAgICAgICBkZXNjcmlwdGlvbjogZ3JvdXBzLmRlc2NyaXB0aW9uLFxyXG4gICAgICAgIG1heE1lbWJlcnM6IGdyb3Vwcy5tYXhNZW1iZXJzLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogZ3JvdXBzLmNyZWF0ZWRBdCxcclxuICAgICAgICBpc093bmVyOiBzcWw8Ym9vbGVhbj5gJHtncm91cHMub3duZXJJZH0gPSAke3Nlc3Npb24udXNlci5pZH1gLFxyXG4gICAgICAgIG1lbWJlclJvbGU6IGdyb3VwTWVtYmVycy5yb2xlLFxyXG4gICAgICAgIGV2ZW50OiB7XHJcbiAgICAgICAgICBpZDogZXZlbnRzLmlkLFxyXG4gICAgICAgICAgc2x1ZzogZXZlbnRzLnNsdWcsXHJcbiAgICAgICAgICB0aXRsZTogZXZlbnRzLnRpdGxlLFxyXG4gICAgICAgICAgaW1hZ2VVcmw6IGV2ZW50cy5pbWFnZVVybCxcclxuICAgICAgICAgIGV2ZW50RGF0ZTogZXZlbnRzLmV2ZW50RGF0ZSxcclxuICAgICAgICAgIGV2ZW50VGltZTogZXZlbnRzLmV2ZW50VGltZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG1lbWJlckNvdW50OiBzcWw8bnVtYmVyPmAoXHJcbiAgICAgICAgICBTRUxFQ1QgQ09VTlQoKik6OmludCBcclxuICAgICAgICAgIEZST00gJHtncm91cE1lbWJlcnN9IGdtIFxyXG4gICAgICAgICAgV0hFUkUgZ20uZ3JvdXBfaWQgPSAke2dyb3Vwcy5pZH0gXHJcbiAgICAgICAgICBBTkQgZ20uc3RhdHVzID0gJ2FjdGl2ZSdcclxuICAgICAgICApYCxcclxuICAgICAgfSlcclxuICAgICAgLmZyb20oZ3JvdXBNZW1iZXJzKVxyXG4gICAgICAuaW5uZXJKb2luKGdyb3VwcywgZXEoZ3JvdXBNZW1iZXJzLmdyb3VwSWQsIGdyb3Vwcy5pZCkpXHJcbiAgICAgIC5pbm5lckpvaW4oZXZlbnRzLCBlcShncm91cHMuZXZlbnRJZCwgZXZlbnRzLmlkKSlcclxuICAgICAgLndoZXJlKFxyXG4gICAgICAgIGFuZChcclxuICAgICAgICAgIGVxKGdyb3VwTWVtYmVycy51c2VySWQsIHNlc3Npb24udXNlci5pZCksXHJcbiAgICAgICAgICBlcShncm91cE1lbWJlcnMuc3RhdHVzLCBcImFjdGl2ZVwiKSxcclxuICAgICAgICAgIGVxKGdyb3Vwcy5pc0FjdGl2ZSwgdHJ1ZSksXHJcbiAgICAgICAgICBndChldmVudHMuZXZlbnREYXRlLCBuZXcgRGF0ZSgpKVxyXG4gICAgICAgIClcclxuICAgICAgKVxyXG4gICAgICAub3JkZXJCeShldmVudHMuZXZlbnREYXRlKTtcclxuXHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBteUdyb3VwcyB9O1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyZXVyIHLDqWN1cMOpcmF0aW9uIG1lcyBncm91cGVzOlwiLCBlcnJvcik7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgZXJyb3I6IFwiRXJyZXVyIGxvcnMgZGUgbGEgcsOpY3Vww6lyYXRpb24gZGUgdm9zIGdyb3VwZXNcIixcclxuICAgIH07XHJcbiAgfVxyXG59XHJcblxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vIEhJU1RPUklRVUUgREVTIEVWRU5UUyBQQVNTw4lTIEFVWFFVRUxTIEwnVVRJTElTQVRFVVIgQSBQQVJUSUNJUMOJXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE15UGFzdENvbmNlcnRzKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aC5hcGkuZ2V0U2Vzc2lvbih7XHJcbiAgICAgIGhlYWRlcnM6IGF3YWl0IGhlYWRlcnMoKSxcclxuICAgIH0pO1xyXG5cclxuICAgIGlmICghc2Vzc2lvbikge1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiTm9uIGF1dGhlbnRpZmnDqVwiIH07XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbXlQYXN0Q29uY2VydHMgPSBhd2FpdCBkYlxyXG4gICAgICAuc2VsZWN0KHtcclxuICAgICAgICBpZDogZXZlbnRzLmlkLFxyXG4gICAgICAgIHNsdWc6IGV2ZW50cy5zbHVnLFxyXG4gICAgICAgIHRpdGxlOiBldmVudHMudGl0bGUsXHJcbiAgICAgICAgaW1hZ2VVcmw6IGV2ZW50cy5pbWFnZVVybCxcclxuICAgICAgICBldmVudERhdGU6IGV2ZW50cy5ldmVudERhdGUsXHJcbiAgICAgICAgZXZlbnRUaW1lOiBldmVudHMuZXZlbnRUaW1lLFxyXG4gICAgICAgIGdyb3VwSWQ6IGdyb3Vwcy5pZCxcclxuICAgICAgICBncm91cE5hbWU6IGdyb3Vwcy5uYW1lLFxyXG4gICAgICB9KVxyXG4gICAgICAuZnJvbShncm91cE1lbWJlcnMpXHJcbiAgICAgIC5pbm5lckpvaW4oZ3JvdXBzLCBlcShncm91cE1lbWJlcnMuZ3JvdXBJZCwgZ3JvdXBzLmlkKSlcclxuICAgICAgLmlubmVySm9pbihldmVudHMsIGVxKGdyb3Vwcy5ldmVudElkLCBldmVudHMuaWQpKVxyXG4gICAgICAud2hlcmUoXHJcbiAgICAgICAgYW5kKFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLnVzZXJJZCwgc2Vzc2lvbi51c2VyLmlkKSxcclxuICAgICAgICAgIGVxKGdyb3VwTWVtYmVycy5zdGF0dXMsIFwiYWN0aXZlXCIpLFxyXG4gICAgICAgICAgZXEoZ3JvdXBzLmlzQWN0aXZlLCB0cnVlKSxcclxuICAgICAgICAgIGx0KGV2ZW50cy5ldmVudERhdGUsIG5ldyBEYXRlKCkpXHJcbiAgICAgICAgKVxyXG4gICAgICApXHJcbiAgICAgIC5vcmRlckJ5KGRlc2MoZXZlbnRzLmV2ZW50RGF0ZSkpO1xyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IG15UGFzdENvbmNlcnRzIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJldXIgcsOpY3Vww6lyYXRpb24gbWVzIGNvbmNlcnRzIHBhc3PDqXM6XCIsIGVycm9yKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICBlcnJvcjogXCJFcnJldXIgbG9ycyBkZSBsYSByw6ljdXDDqXJhdGlvbiBkZSB2b3MgY29uY2VydHMgcGFzc8Opc1wiLFxyXG4gICAgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gUsOJQ1VQw4lSRVIgTEVTIE1FTUJSRVMgRCdVTiBHUk9VUEVcclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0R3JvdXBNZW1iZXJzKGdyb3VwSWQ6IG51bWJlcikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBtZW1iZXJzID0gYXdhaXQgZGJcclxuICAgICAgLnNlbGVjdCh7XHJcbiAgICAgICAgaWQ6IGdyb3VwTWVtYmVycy5pZCxcclxuICAgICAgICByb2xlOiBncm91cE1lbWJlcnMucm9sZSxcclxuICAgICAgICBzdGF0dXM6IGdyb3VwTWVtYmVycy5zdGF0dXMsXHJcbiAgICAgICAgam9pbmVkQXQ6IGdyb3VwTWVtYmVycy5qb2luZWRBdCxcclxuICAgICAgICB1c2VyOiB7XHJcbiAgICAgICAgICBpZDogdXNlci5pZCxcclxuICAgICAgICAgIG5hbWU6IHVzZXIubmFtZSxcclxuICAgICAgICAgIGF2YXRhcl91cmw6IHVzZXIuYXZhdGFyX3VybCxcclxuICAgICAgICB9LFxyXG4gICAgICB9KVxyXG4gICAgICAuZnJvbShncm91cE1lbWJlcnMpXHJcbiAgICAgIC5pbm5lckpvaW4odXNlciwgZXEoZ3JvdXBNZW1iZXJzLnVzZXJJZCwgdXNlci5pZCkpXHJcbiAgICAgIC53aGVyZShcclxuICAgICAgICBhbmQoXHJcbiAgICAgICAgICBlcShncm91cE1lbWJlcnMuZ3JvdXBJZCwgZ3JvdXBJZCksXHJcbiAgICAgICAgICBlcShncm91cE1lbWJlcnMuc3RhdHVzLCBcImFjdGl2ZVwiKVxyXG4gICAgICAgIClcclxuICAgICAgKVxyXG4gICAgICAub3JkZXJCeShncm91cE1lbWJlcnMuam9pbmVkQXQpO1xyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IG1lbWJlcnMsIGlzTWVtYmVyOiBtZW1iZXJzLmxlbmd0aCA+IDAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycmV1ciByw6ljdXDDqXJhdGlvbiBtZW1icmVzIGR1IGdyb3VwZTpcIiwgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOiBcIkVycmV1ciBsb3JzIGRlIGxhIHLDqWN1cMOpcmF0aW9uIGRlcyBtZW1icmVzIGR1IGdyb3VwZVwiLFxyXG4gICAgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gVsOJUklGSUVSIExFIFNUQVRVVCBERSBMJ1VUSUxJU0FURVVSIERBTlMgVU4gR1JPVVBFXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFVzZXJHcm91cFN0YXR1cyhncm91cElkOiBudW1iZXIpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGF1dGguYXBpLmdldFNlc3Npb24oe1xyXG4gICAgICBoZWFkZXJzOiBhd2FpdCBoZWFkZXJzKCksXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoIXNlc3Npb24pIHtcclxuICAgICAgcmV0dXJuIHsgXHJcbiAgICAgICAgc3VjY2VzczogdHJ1ZSwgXHJcbiAgICAgICAgaXNNZW1iZXI6IGZhbHNlLCBcclxuICAgICAgICByb2xlOiBudWxsLFxyXG4gICAgICAgIHN0YXR1czogbnVsbCBcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBbbWVtYmVyXSA9IGF3YWl0IGRiXHJcbiAgICAgIC5zZWxlY3Qoe1xyXG4gICAgICAgIHJvbGU6IGdyb3VwTWVtYmVycy5yb2xlLFxyXG4gICAgICAgIHN0YXR1czogZ3JvdXBNZW1iZXJzLnN0YXR1cyxcclxuICAgICAgfSlcclxuICAgICAgLmZyb20oZ3JvdXBNZW1iZXJzKVxyXG4gICAgICAud2hlcmUoXHJcbiAgICAgICAgYW5kKFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLmdyb3VwSWQsIGdyb3VwSWQpLFxyXG4gICAgICAgICAgZXEoZ3JvdXBNZW1iZXJzLnVzZXJJZCwgc2Vzc2lvbi51c2VyLmlkKVxyXG4gICAgICAgIClcclxuICAgICAgKVxyXG4gICAgICAubGltaXQoMSk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgaXNNZW1iZXI6IG1lbWJlcj8uc3RhdHVzID09PSBcImFjdGl2ZVwiLFxyXG4gICAgICByb2xlOiBtZW1iZXI/LnJvbGUgfHwgbnVsbCxcclxuICAgICAgc3RhdHVzOiBtZW1iZXI/LnN0YXR1cyB8fCBudWxsLFxyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkVycmV1ciB2w6lyaWZpY2F0aW9uIHN0YXR1dCB1dGlsaXNhdGV1cjpcIiwgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOiBcIkVycmV1ciBsb3JzIGRlIGxhIHbDqXJpZmljYXRpb24gZHUgc3RhdHV0XCIsXHJcbiAgICB9O1xyXG4gIH1cclxufVxyXG5cclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyBSw4lDVVDDiVJFUiBVTiBHUk9VUEUgUEFSIFNPTiBJRFxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRHcm91cEJ5SWQoZ3JvdXBJZDogbnVtYmVyKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBhdXRoLmFwaS5nZXRTZXNzaW9uKHtcclxuICAgICAgaGVhZGVyczogYXdhaXQgaGVhZGVycygpLFxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKCFzZXNzaW9uKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJOb24gYXV0aGVudGlmacOpXCIgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBbZ3JvdXBdID0gYXdhaXQgZGJcclxuICAgICAgLnNlbGVjdCh7XHJcbiAgICAgICAgaWQ6IGdyb3Vwcy5pZCxcclxuICAgICAgICBuYW1lOiBncm91cHMubmFtZSxcclxuICAgICAgICBkZXNjcmlwdGlvbjogZ3JvdXBzLmRlc2NyaXB0aW9uLFxyXG4gICAgICAgIG1heE1lbWJlcnM6IGdyb3Vwcy5tYXhNZW1iZXJzLFxyXG4gICAgICAgIGlzQWN0aXZlOiBncm91cHMuaXNBY3RpdmUsXHJcbiAgICAgICAgY3JlYXRlZEF0OiBncm91cHMuY3JlYXRlZEF0LFxyXG4gICAgICAgIGV2ZW50SWQ6IGdyb3Vwcy5ldmVudElkLFxyXG4gICAgICAgIG93bmVySWQ6IHtcclxuICAgICAgICAgIGlkOiB1c2VyLmlkLFxyXG4gICAgICAgICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgICAgICAgYXZhdGFyX3VybDogdXNlci5hdmF0YXJfdXJsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgfSlcclxuICAgICAgLmZyb20oZ3JvdXBzKVxyXG4gICAgICAuaW5uZXJKb2luKHVzZXIsIGVxKGdyb3Vwcy5vd25lcklkLCB1c2VyLmlkKSlcclxuICAgICAgLndoZXJlKGVxKGdyb3Vwcy5pZCwgZ3JvdXBJZCkpXHJcbiAgICAgIC5saW1pdCgxKTtcclxuXHJcbiAgICBpZiAoIWdyb3VwKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogXCJHcm91cGUgaW50cm91dmFibGVcIiB9O1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IGdyb3VwIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJldXIgcsOpY3Vww6lyYXRpb24gZ3JvdXBlIHBhciBJRDpcIiwgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgIGVycm9yOiBcIkVycmV1ciBsb3JzIGRlIGxhIHLDqWN1cMOpcmF0aW9uIGR1IGdyb3VwZVwiLFxyXG4gICAgfTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJrU0EwWXNCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/auth-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authClient",
    ()=>authClient,
    "signIn",
    ()=>signIn,
    "signOut",
    ()=>signOut,
    "signUp",
    ()=>signUp,
    "useSession",
    ()=>useSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/better-auth/dist/client/react/index.mjs [app-client] (ecmascript) <locals>");
;
const authClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAuthClient"])({
    baseURL: ("TURBOPACK compile-time value", "http://localhost:3000") || "http://localhost:3000"
});
const { signIn, signUp, signOut, useSession } = authClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/groups/components/MyGroupCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MyGroupCard",
    ()=>MyGroupCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-client] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$speaker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Speaker$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/speaker.js [app-client] (ecmascript) <export default as Speaker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/crown.js [app-client] (ecmascript) <export default as Crown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
"use client";
;
;
;
;
function MyGroupCard({ group }) {
    const formatDate = (date)=>{
        return new Date(date).toLocaleDateString("fr-FR", {
            day: "numeric",
            month: "long",
            year: "numeric"
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative h-40 bg-gray-200",
                children: [
                    group.event.imageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: group.event.imageUrl,
                        alt: group.event.title,
                        className: "w-full h-full object-cover",
                        width: 640,
                        height: 360
                    }, void 0, false, {
                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                        lineNumber: 23,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full h-full flex items-center justify-center text-gray-400",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                            className: "w-12 h-12"
                        }, void 0, false, {
                            fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                        lineNumber: 31,
                        columnNumber: 11
                    }, this),
                    group.isOwner && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-2 right-2 bg-orange-fonce text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-lg",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$crown$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Crown$3e$__["Crown"], {
                                className: "w-3 h-3"
                            }, void 0, false, {
                                fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                lineNumber: 38,
                                columnNumber: 13
                            }, this),
                            "Créateur"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl font-bold text-gray-900 mb-2",
                        children: group.name
                    }, void 0, false, {
                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    group.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-gray-600 mb-3 line-clamp-2",
                        children: group.description
                    }, void 0, false, {
                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                        lineNumber: 51,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: `/concerts/${group.event.slug}`,
                        className: "block mb-3 p-3 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "font-semibold text-gray-900 mb-1 flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                        className: "w-4 h-4 text-orange-fonce"
                                    }, void 0, false, {
                                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                        lineNumber: 62,
                                        columnNumber: 13
                                    }, this),
                                    group.event.title
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                lineNumber: 61,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 text-sm text-gray-600",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                        className: "w-3 h-3"
                                    }, void 0, false, {
                                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                        lineNumber: 66,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: formatDate(group.event.eventDate)
                                    }, void 0, false, {
                                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                        lineNumber: 67,
                                        columnNumber: 13
                                    }, this),
                                    group.event.eventTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            "• ",
                                            group.event.eventTime
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                        lineNumber: 68,
                                        columnNumber: 39
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                lineNumber: 65,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 mb-4 text-gray-700",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                className: "w-4 h-4"
                            }, void 0, false, {
                                fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                lineNumber: 74,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm",
                                children: [
                                    group.memberCount,
                                    " / ",
                                    group.maxMembers,
                                    " membres"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                lineNumber: 75,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: `/concerts/${group.event.slug}`,
                                className: "flex-1 flex items-center justify-center gap-2 bg-orange-clair text-white px-4 py-3 rounded-lg hover:bg-orange-900 transition-colors font-medium",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$speaker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Speaker$3e$__["Speaker"], {}, void 0, false, {
                                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                        lineNumber: 97,
                                        columnNumber: 15
                                    }, this),
                                    "Voir l'événement"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                                lineNumber: 93,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                            lineNumber: 92,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                        lineNumber: 81,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/groups/components/MyGroupCard.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/groups/components/MyGroupCard.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = MyGroupCard;
var _c;
__turbopack_context__.k.register(_c, "MyGroupCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/groups/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MyGroupsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$d4df34__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:d4df34 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$auth$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/auth-client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$groups$2f$components$2f$MyGroupCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/groups/components/MyGroupCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function MyGroupsPage() {
    _s();
    const { data: session, isPending } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$auth$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"])();
    const [groups, setGroups] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchMyGroups = async ()=>{
        setIsLoading(true);
        setError(null);
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$d4df34__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getMyGroups"])();
        if (result.success) {
            setGroups(result.data || []);
        } else {
            setError(result.error || "Erreur lors du chargement de vos groupes");
        }
        setIsLoading(false);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MyGroupsPage.useEffect": ()=>{
            const fetchData = {
                "MyGroupsPage.useEffect.fetchData": async ()=>{
                    if (!isPending && session?.user) {
                        await fetchMyGroups();
                    } else if (!isPending && !session) {
                        setIsLoading(false);
                    }
                }
            }["MyGroupsPage.useEffect.fetchData"];
            fetchData();
        }
    }["MyGroupsPage.useEffect"], [
        session,
        isPending
    ]);
    const handleGroupUpdate = ()=>{
        fetchMyGroups();
    };
    // Loading state
    if (isPending || isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                className: "w-12 h-12 animate-spin text-orange-clair"
            }, void 0, false, {
                fileName: "[project]/app/groups/page.tsx",
                lineNumber: 71,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/groups/page.tsx",
            lineNumber: 70,
            columnNumber: 7
        }, this);
    }
    // Not authenticated
    if (!session?.user) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-8 flex items-center justify-center px-4 md:mt-16",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center max-w-md",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                        className: "w-16 h-16 text-gray-400 mx-auto mb-4"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 81,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-2xl font-bold text-white mb-2",
                        children: "Mes groupes"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-400 mb-6",
                        children: "Vous devez être connecté pour voir vos groupes"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 85,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/login",
                        className: "inline-block bg-orange-clair text-black font-medium px-6 py-3 rounded hover:bg-orange-600 hover:text-white transition-colors",
                        children: "Se connecter"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/groups/page.tsx",
                lineNumber: 80,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/groups/page.tsx",
            lineNumber: 79,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-7xl mx-auto px-4 py-8 pb-24 md:py-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-3xl font-bold text-white mb-2 flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                className: "w-8 h-8 text-orange-clair"
                            }, void 0, false, {
                                fileName: "[project]/app/groups/page.tsx",
                                lineNumber: 104,
                                columnNumber: 11
                            }, this),
                            "Mes groupes"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-400",
                        children: "Gérez vos groupes et suivez vos événements à venir"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/groups/page.tsx",
                lineNumber: 102,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                        className: "w-5 h-5 text-red-600 shrink-0 mt-0.5"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 115,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "font-semibold text-red-800 mb-1",
                                children: "Erreur"
                            }, void 0, false, {
                                fileName: "[project]/app/groups/page.tsx",
                                lineNumber: 117,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-red-600",
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/app/groups/page.tsx",
                                lineNumber: 118,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 116,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/groups/page.tsx",
                lineNumber: 114,
                columnNumber: 9
            }, this),
            groups.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-16 bg-white/5 rounded-lg border-2 border-dashed border-white/10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                        className: "w-16 h-16 text-gray-400 mx-auto mb-4"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 126,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-semibold text-white mb-2",
                        children: "Aucun groupe pour le moment"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 127,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-400 mb-6 max-w-md mx-auto",
                        children: "Explorez les événements et rejoignez ou créez un groupe pour partager votre passion avec d'autres fans !"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 130,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/concerts",
                        className: "inline-block bg-orange-clair text-black font-medium px-6 py-3 rounded hover:bg-orange-600 hover:text-white transition-colors",
                        children: "Découvrir les événements"
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 134,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/groups/page.tsx",
                lineNumber: 125,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6 grid grid-cols-2 md:grid-cols-4 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white/10 rounded-lg p-4 border border-white/20",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-3xl font-bold text-orange-clair mb-1",
                                        children: groups.length
                                    }, void 0, false, {
                                        fileName: "[project]/app/groups/page.tsx",
                                        lineNumber: 146,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm text-gray-400",
                                        children: groups.length > 1 ? "Groupes" : "Groupe"
                                    }, void 0, false, {
                                        fileName: "[project]/app/groups/page.tsx",
                                        lineNumber: 149,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/groups/page.tsx",
                                lineNumber: 145,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white/10 rounded-lg p-4 border border-white/20",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-3xl font-bold text-orange-clair mb-1",
                                        children: groups.filter((g)=>g.isOwner).length
                                    }, void 0, false, {
                                        fileName: "[project]/app/groups/page.tsx",
                                        lineNumber: 154,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm text-gray-400",
                                        children: "Créés par vous"
                                    }, void 0, false, {
                                        fileName: "[project]/app/groups/page.tsx",
                                        lineNumber: 157,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/groups/page.tsx",
                                lineNumber: 153,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 144,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
                        children: groups.map((group)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$groups$2f$components$2f$MyGroupCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MyGroupCard"], {
                                group: group,
                                onUpdate: handleGroupUpdate
                            }, group.id, false, {
                                fileName: "[project]/app/groups/page.tsx",
                                lineNumber: 166,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/groups/page.tsx",
                        lineNumber: 164,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/app/groups/page.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
_s(MyGroupsPage, "EcBuxzWJ1en5iCxyzDG4siYL6wk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$auth$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"]
    ];
});
_c = MyGroupsPage;
var _c;
__turbopack_context__.k.register(_c, "MyGroupsPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_2b517810._.js.map