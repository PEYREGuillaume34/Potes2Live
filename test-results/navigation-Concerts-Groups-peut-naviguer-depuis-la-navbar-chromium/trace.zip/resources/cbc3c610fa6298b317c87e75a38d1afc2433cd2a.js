(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_dca84697._.js",
  "static/chunks/app_concerts_497991c6._.js"
],
    source: "dynamic"
});
